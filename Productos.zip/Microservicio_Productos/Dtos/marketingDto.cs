﻿namespace Microservicio_Productos.Dtos
{
    public class marketingDto
    {
        public Guid idProducto { get; set; }
    }
}
