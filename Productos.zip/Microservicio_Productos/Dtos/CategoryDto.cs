﻿namespace Microservicio_Productos.Dtos
{
    public class CategoryDto
    {
        public string CategoryName { get; set; }
    }
}
