﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Microservicio_Productos.Migrations
{
    public partial class CrearDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
